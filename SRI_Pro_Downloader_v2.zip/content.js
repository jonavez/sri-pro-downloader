// content.js - Lógica de extracción e interacción con la página

function extractInvoiceData() {
  const invoices = [];
  // Selector ajustado para PrimeFaces/JSF común en SRI
  const table = document.querySelector('table[id*="tablaCompRecibidos"]');
  
  if (!table) {
    console.warn('Tabla no encontrada');
    return { invoices: [], total: 0 };
  }
  
  const rows = table.querySelectorAll('tbody tr[data-ri]');
  
  rows.forEach((row, index) => {
    try {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 9) {
        // Extracción robusta
        const numero = cells[0].innerText.trim();
        const rucRaw = cells[1].innerText.trim(); // Puede contener RUC \n Razón Social
        const parts = rucRaw.split('\n');
        const ruc = parts[0].trim();
        const razonSocial = parts.length > 1 ? parts[1].trim() : '';
        
        const tipoSerie = cells[2].innerText.trim();
        const claveAcceso = cells[3].innerText.trim(); // A veces está oculta o en tooltip
        const fechaAutorizacion = cells[4].innerText.trim();
        const fechaEmision = cells[5].innerText.trim();
        const valorSinImpuestos = cells[6].innerText.trim();
        const iva = cells[7].innerText.trim();
        const importeTotal = cells[8].innerText.trim();
        
        // Buscar botón/link XML
        const xmlLink = row.querySelector('a[id*="lnkXml"]');
        
        if (xmlLink) {
          invoices.push({
            numero,
            ruc,
            razonSocial,
            tipoSerie,
            claveAcceso,
            fechaAutorizacion,
            fechaEmision,
            valorSinImpuestos,
            iva,
            importeTotal,
            xmlLinkId: xmlLink.id,
            rowIndex: index
          });
        }
      }
    } catch (e) {
      console.error('Error parsing row', e);
    }
  });
  
  return { invoices, total: invoices.length };
}

// Simular clic y manejar descarga
async function downloadSingleXML(linkId, filename) {
  const link = document.getElementById(linkId);
  if (!link) return false;

  // En SRI, el clic dispara un POST y luego descarga. 
  // No podemos interceptar fácilmente el blob sin intervenir la red.
  // Lo mejor es hacer click y dejar que el navegador (y nuestro background) maneje la descarga.
  // PERO, para renombrar, necesitamos interceptar.
  
  // Estrategia simple: Clic y confiar en Chrome. 
  // Estrategia avanzada (SRI Pro): Interceptar el request.
  
  // Por ahora, mantenemos la estrategia de clic simple pero secuencial.
  link.click();
  
  // Esperar un poco para asegurar que el evento se procese
  await new Promise(r => setTimeout(r, 1500));
  return true;
}

// Navegación
function hasNextPage() {
  const nextBtn = document.querySelector('.ui-paginator-next');
  return nextBtn && !nextBtn.classList.contains('ui-state-disabled');
}

async function goToNextPage() {
  const nextBtn = document.querySelector('.ui-paginator-next');
  if (nextBtn) {
    nextBtn.click();
    // Esperar a que cargue la tabla (spinner desaparezca o tabla cambie)
    await new Promise(r => setTimeout(r, 3000)); 
  }
}

// Listeners
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractInvoices') {
    sendResponse(extractInvoiceData());
  }
  
  if (request.action === 'downloadSingleXML') {
    downloadSingleXML(request.linkId, request.filename)
      .then(() => sendResponse({success: true}))
      .catch(e => sendResponse({success: false, error: e.message}));
    return true;
  }
  
  if (request.action === 'downloadAllPages') {
    processAllPages();
    sendResponse({started: true});
  }
});

async function processAllPages() {
  let page = 1;
  let totalProcessed = 0;
  
  while (true) {
    const data = extractInvoiceData();
    const invoices = data.invoices;
    
    // Descargar de esta página
    for (let i = 0; i < invoices.length; i++) {
      await downloadSingleXML(invoices[i].xmlLinkId);
      totalProcessed++;
      
      // Reportar progreso
      chrome.runtime.sendMessage({
        action: 'updateProgress',
        current: totalProcessed,
        total: '?' // Desconocido total real
      });
    }
    
    if (hasNextPage()) {
      await goToNextPage();
      page++;
    } else {
      break;
    }
  }
  
  chrome.runtime.sendMessage({
    action: 'updateProgress',
    current: totalProcessed,
    total: totalProcessed
  });
}
