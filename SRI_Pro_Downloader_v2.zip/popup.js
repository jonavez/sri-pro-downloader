import { convertToCSV, downloadCSV } from './excel_export.js';
import { generateFilename } from './utils.js';

document.addEventListener('DOMContentLoaded', function() {
  // Elementos UI
  const scanBtn = document.getElementById('scanBtn');
  const downloadBtn = document.getElementById('downloadBtn');
  const exportBtn = document.getElementById('exportBtn');
  const downloadAllBtn = document.getElementById('downloadAllBtn');
  const actionButtons = document.getElementById('actionButtons');
  const listContainer = document.getElementById('listContainer');
  const facturasList = document.getElementById('facturasList');
  const progressContainer = document.getElementById('progressContainer');
  const progressBar = document.getElementById('progressBar');
  const progressText = document.getElementById('progressText');
  
  // Stats
  const totalInvoicesEl = document.getElementById('totalInvoices');
  const totalAmountEl = document.getElementById('totalAmount');

  let currentInvoices = [];

  // 1. Escanear
  scanBtn.addEventListener('click', async () => {
    updateStatus('Escaneando...', 0);
    
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    
    if (!tab) {
      updateStatus('Error: No se detectó pestaña activa', 0, true);
      return;
    }

    try {
      const response = await chrome.tabs.sendMessage(tab.id, {action: 'extractInvoices'});
      
      if (response && response.invoices) {
        currentInvoices = response.invoices;
        updateDashboard(currentInvoices);
        
        actionButtons.style.display = 'block';
        listContainer.style.display = 'block';
        progressContainer.style.display = 'none';
        
        renderList(currentInvoices);
      } else {
        updateStatus('No se encontraron facturas o error en la página', 0, true);
      }
    } catch (error) {
      console.error(error);
      updateStatus('Error de conexión. Recarga la página del SRI.', 0, true);
    }
  });

  // 2. Descargar XMLs
  downloadBtn.addEventListener('click', () => {
    if (currentInvoices.length === 0) return;
    processDownloads(currentInvoices);
  });

  // 3. Exportar Excel
  exportBtn.addEventListener('click', () => {
    if (currentInvoices.length === 0) return;
    const csv = convertToCSV(currentInvoices);
    downloadCSV(csv, `reporte_sri_${new Date().toISOString().slice(0,10)}.csv`);
  });

  // 4. Descargar Todo (Paginación)
  downloadAllBtn.addEventListener('click', () => {
    // Lógica compleja delegada al content script
    startBatchDownload();
  });

  // Funciones Helper
  function updateDashboard(invoices) {
    totalInvoicesEl.textContent = invoices.length;
    
    const total = invoices.reduce((sum, inv) => {
      const val = parseFloat(inv.importeTotal.replace(',', '.') || 0);
      return sum + val;
    }, 0);
    
    totalAmountEl.textContent = `$${total.toFixed(2)}`;
  }

  function renderList(invoices) {
    facturasList.innerHTML = invoices.map(inv => `
      <div class="invoice-item">
        <div class="invoice-info">
          <span style="font-weight:600; font-size:0.8rem;">${inv.razonSocial}</span>
          <span style="color:#64748b; font-size:0.75rem;">${inv.numero}</span>
        </div>
        <div class="invoice-amount">$${inv.importeTotal}</div>
      </div>
    `).join('');
  }

  function updateStatus(text, percent, isError = false) {
    progressContainer.style.display = 'block';
    progressText.textContent = text;
    progressText.style.color = isError ? '#ef4444' : '#64748b';
    progressBar.style.width = `${percent}%`;
    progressBar.style.backgroundColor = isError ? '#ef4444' : '#10b981';
  }

  async function processDownloads(invoices) {
    updateStatus('Iniciando descargas...', 0);
    
    let completed = 0;
    const total = invoices.length;
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});

    for (const inv of invoices) {
      try {
        // 1. Obtener URL del XML (esto requiere interacción con la página para obtener el blob o link real)
        // En la versión actual del SRI, a veces es un link directo o un JS que genera descarga.
        // Vamos a pedir al content script que "haga click" y nos de la URL o maneje la descarga.
        
        // Opción A: Content script descarga y background renombra.
        // Opción B: Content script obtiene URL y popup/background descarga.
        
        // Usaremos el método del content script existente pero mejorado
        await chrome.tabs.sendMessage(tab.id, {
          action: 'downloadSingleXML',
          linkId: inv.xmlLinkId,
          filename: generateFilename(inv)
        });
        
        completed++;
        updateStatus(`Descargando ${completed}/${total}`, (completed/total)*100);
        
      } catch (e) {
        console.error('Error descargando', inv, e);
      }
      
      // Pequeña pausa para no saturar
      await new Promise(r => setTimeout(r, 500));
    }
    
    updateStatus('¡Descarga completada!', 100);
    setTimeout(() => {
      progressContainer.style.display = 'none';
    }, 3000);
  }

  function startBatchDownload() {
    updateStatus('Iniciando descarga masiva...', 0);
    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'downloadAllPages'
      });
    });
  }

  // Escuchar progreso global (para descarga masiva)
  chrome.runtime.onMessage.addListener((request) => {
    if (request.action === 'updateProgress') {
      const percent = (request.current / request.total) * 100;
      updateStatus(`Procesando: ${request.current}/${request.total}`, percent);
    }
  });
});
