import { generateFilename } from './utils.js';

// Escuchar mensajes desde el popup o content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'downloadFile') {
    handleDownload(request.url, request.filename, sendResponse);
    return true; // Asíncrono
  }
});

// Manejar la descarga usando chrome.downloads API
function handleDownload(url, filename, sendResponse) {
  chrome.downloads.download({
    url: url,
    filename: filename,
    conflictAction: 'uniquify',
    saveAs: false
  }, (downloadId) => {
    if (chrome.runtime.lastError) {
      sendResponse({ success: false, error: chrome.runtime.lastError.message });
    } else {
      sendResponse({ success: true, downloadId: downloadId });
    }
  });
}

// Instalación
chrome.runtime.onInstalled.addListener(() => {
  console.log('SRI Pro Downloader instalado correctamente.');
});
